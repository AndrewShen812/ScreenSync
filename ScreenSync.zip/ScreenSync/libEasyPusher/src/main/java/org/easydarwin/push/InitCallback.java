package org.easydarwin.push;

/**
 * Created by john on 2017/5/6.
 */

public interface InitCallback {
    public void onCallback(int code);
}
