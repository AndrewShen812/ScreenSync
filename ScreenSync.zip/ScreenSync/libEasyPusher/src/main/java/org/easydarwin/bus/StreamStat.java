package org.easydarwin.bus;

/**
 * Created by apple on 2017/5/14.
 */

public class StreamStat {
    public final int fps, bps;

    public StreamStat(int fps, int bps) {
        this.fps = fps;
        this.bps = bps;
    }
}
