package org.easydarwin.bus;

/**
 * Created by apple on 2017/8/29.
 */

public class SupportResolution {
}
